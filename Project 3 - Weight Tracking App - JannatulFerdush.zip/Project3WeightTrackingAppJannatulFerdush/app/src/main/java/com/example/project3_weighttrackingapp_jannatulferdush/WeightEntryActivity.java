package com.example.project3_weighttrackingapp_jannatulferdush;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WeightEntryActivity extends AppCompatActivity {

    private EditText editTextDate, editTextWeight;
    private Button buttonAddWeight, buttonShowWeights;
    private DatabaseHelper databaseHelper;
    private GridLayout gridLayout;

    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonShowWeights = findViewById(R.id.buttonShowWeights);
        gridLayout = findViewById(R.id.gridLayout);

        databaseHelper = new DatabaseHelper(this);

        buttonAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = editTextDate.getText().toString();
                String weight = editTextWeight.getText().toString();
                if (databaseHelper.addWeight(date, weight)) {
                    Toast.makeText(WeightEntryActivity.this, "Weight added", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(WeightEntryActivity.this, "Weight entry failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonShowWeights.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadWeightEntries();
            }
        });
    }

    private void loadWeightEntries() {
        gridLayout.removeAllViews(); // Clear previous entries
        Cursor cursor = databaseHelper.getAllWeights();
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE));
            @SuppressLint("Range") String weight = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT));
            addWeightEntryToGrid(date, weight);
        }
        cursor.close();
    }

    private void addWeightEntryToGrid(String date, String weight) {
        LinearLayout rowLayout = new LinearLayout(this);
        rowLayout.setOrientation(LinearLayout.HORIZONTAL);

        // Create TextViews for date and weight
        TextView dateTextView = new TextView(this);
        dateTextView.setText(date);
        TextView weightTextView = new TextView(this);
        weightTextView.setText(weight);

        // Create delete button
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(v -> {
            databaseHelper.deleteWeight(date);
            loadWeightEntries(); // Refresh the grid
        });

        rowLayout.addView(dateTextView);
        rowLayout.addView(weightTextView);
        rowLayout.addView(deleteButton);
        gridLayout.addView(rowLayout);
    }
}
